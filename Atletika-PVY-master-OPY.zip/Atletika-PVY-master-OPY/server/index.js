const fs = require("fs");
const Joi = require("joi");
const cors = require("cors");
const express = require("express");
const app = express();
app.use(express.json());
app.use(cors());

const atleti = require("./atleti.json");

app.get("/", (req, res) => {
  res.send("<h1>Úvodní stránka - REST API</h1>");
});

app.get("/api/atleti", (req, res) => {
  res.send(atleti);
});

app.get("/api/atleti/:id", (req, res) => {
  const id = Number(req.params.id);
  const atlet = atleti.find(atlet => atlet.id === id);
  if (atlet) {
    res.send(atlet);
  } else {
    res.status(404).send("Atlet nebyl nalezen.");
  }
});

app.post("/api/atleti", (req, res) => {
  const { error } = validateatlet(req.body);
  if (error) {
    res.status(400).send(error);
  } else {
    const atlet = {
      id: atleti.length !== 0 ? atleti[atleti.length - 1].id + 1 : 1,
      name: req.body.name,
      year: req.body.year,
      state: req.body.state,
      spec: req.body.spec,
      content: req.body.content,
    };
    atleti.push(atlet);
    res.send(atlet);
    writeJSON(atleti, "atleti.json");
  }
});

app.put("/api/atleti/:id", (req, res) => {
  const id = Number(req.params.id);
  const atlet = atleti.find(atlet => atlet.id === id);
  if (!atlet) {
    res.status(404).send("Atlet nebyl nalezen.");
    return;
  }
  const { error } = validateatlet(req.body);
  if (error) {
    res.status(400).send(error.details[0].message);
  } else {
    atlet.name = req.body.name;
    atlet.year = req.body.year;
    atlet.state = req.body.state;
    atlet.spec = req.body.spec;
    atlet.content = req.body.content;
    res.send(atlet);
    writeJSON(atleti, "atleti.json");
  }
});

app.delete("/api/atleti/:id", (req, res) => {
  const id = Number(req.params.id);
  const atlet = atleti.find(atlet => atlet.id === id);
  if (!atlet) {
    res.status(404).send("Atlet nebyl nalezen.");
  } else {
    const index = atleti.indexOf(atlet);
    atleti.splice(index, 1);
    res.send(atlet);
    writeJSON(atleti, "atleti.json");
  }
});

app.listen(3000, () => console.log("Listening on port 3000..."));

function validateatlet(atlet) {
  const schema = {
    name: Joi.string()
      .min(2)
      .required(),
    year: Joi.number(),
    state: Joi.string(),
    spec: Joi.string(),
    content: Joi.string()
  };
  return Joi.validate(atlet, schema);
}

function writeJSON(jsonData, pathToFile) {
  let data = JSON.stringify(jsonData, null, 2);
  fs.writeFile(pathToFile, data, err => {
    if (err) {
      throw err;
    } else {
      console.log("Data written to file");
    }
  });
}
