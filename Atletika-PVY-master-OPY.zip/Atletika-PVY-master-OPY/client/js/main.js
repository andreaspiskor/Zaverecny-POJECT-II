$(function(){
    function getAll() {
        $.ajax({
            url: 'http://localhost:3000/api/atleti',
            type: 'GET',
            dataType: 'json',
            cache: false,
            success: function (data, textStatus, xhr) {
                console.log(textStatus);
                console.log(data);
                $('#list').html('');
                data.forEach(function(atlet) {
                    $('#list').append('<tr><td>'+atlet.id
                        +'</td><td><a href="#" data-id="'+atlet.id+'">'+atlet.name
                        +'</a></td><td>'+atlet.year+'</td><td>'+atlet.state+'</td><td>'+atlet.spec+'</td><td><button class="btn btn-danger delete" data-id="'+atlet.id+'">Smazat</button></td></tr>');
                });
                $('#list a').on('click', function(){
                    getById($(this).data('id'));
                }); 
                $('.delete').on('click', function(){
                    deleteById($(this).data('id'));
                }); 
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        })
    }

    function getById(id) {
        $.ajax({
            url: 'http://localhost:3000/api/atleti/' + id,
            type: 'GET',
            dataType: 'json',
            cache: false,
            success: function (data, textStatus, xhr) {
                console.log(textStatus);
                console.log(data);
                $('#id').val(data.id);
                $('#name').val(data.name);
                $('#year').val(data.year);
                $('#state').val(data.state);
                $('#spec').val(data.spec);
                $('#content').val(data.content);
                $('#modelId').modal('show');
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        })
    }

    function deleteById(id) {
        $.ajax({
            url: 'http://localhost:3000/api/atleti/' + id,
            type: 'DELETE',
            dataType: 'json',
            cache: false,
            success: function (data, textStatus, xhr) {
                console.log(textStatus);
                console.log(data);
                getAll();
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        })
    }

    function create(data) {
        $.ajax({
            url: 'http://localhost:3000/api/atleti',
            type: 'POST',
            data: data,
            dataType: 'json',            
            contentType: 'application/json',
            success: function (data, textStatus, xhr) {
                console.log(textStatus);
                console.log(data);
                getAll();
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        })
    }

    function update(id, data) {
        $.ajax({
            url: 'http://localhost:3000/api/atleti/' + id,
            type: 'PUT',
            data: data,
            dataType: 'json',
            contentType: 'application/json',
            success: function (data, textStatus, xhr) {
                console.log(textStatus);
                console.log(data);
                getAll();
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        })
    }

    $('button#submit').on('click', function(){
        var json = {};
        json.name = $('#name').val();
        json.year = $('#year').val();
        json.state = $('#state').val();
        json.spec = $('#spec').val();
        json.content = $('#content').val();
        var data = JSON.stringify(json);
        if ($('#id').val()) {
            update($('#id').val(), data);
        } else {
            create(data);
        }
    });

    $('button#create').on('click', function(){
        $('#id').val('');
        $('#name').val('');
        $('#year').val('');
        $('#state').val('');
        $('#spec').val('');
        $('#content').val('');
    });

    getAll();
});
    
